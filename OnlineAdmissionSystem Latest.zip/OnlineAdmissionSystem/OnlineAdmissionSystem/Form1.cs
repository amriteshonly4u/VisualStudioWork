﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OnlineAdmissionSystem
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            WriteInReg();
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {
            Environment.Exit(Environment.ExitCode);
        }

        private void label2_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void webBrowser1_DocumentCompleted(object sender, WebBrowserDocumentCompletedEventArgs e)
        {
            
        }

        //to writing in registry to unable the javascript
        Task WriteInReg()
        {
            return Task.Run(() => {
                RegistryKey regKeyDomain = null;
                string app_name = AppDomain.CurrentDomain.DomainManager.EntryAssembly.GetName().Name;

                string key = "Software\\Microsoft\\Internet Explorer\\Main\\FeatureControl\\FEATURE_BROWSER_EMULATION\\";
                regKeyDomain = Registry.CurrentUser.CreateSubKey(key);

                using (regKeyDomain)    //for securely set
                {
                    string vs_host_app_name = app_name + ".vshost.exe";
                    string temp_app_name = app_name + ".exe";
                    regKeyDomain.SetValue(temp_app_name, unchecked((int)0xf00002af9), RegistryValueKind.DWord);
                    regKeyDomain.SetValue(vs_host_app_name, unchecked((int)0xf00002af9), RegistryValueKind.DWord);
                }
                Debug.Print("done printing");
            });
            

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            MessageBox.Show("To go to the previous page press your Backspace key ");
        }
    }
}
