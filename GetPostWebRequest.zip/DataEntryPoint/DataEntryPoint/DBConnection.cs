﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
using System.Data;

namespace TextQuestionToDB
{

    class DBConnection
    {
        private MySqlConnection connection;
        private string server;
        private string database;
        private string uid;
        private string password;
        private OleDbConnection oledb;

        //Constructor
        public DBConnection()
        {
            Initialize();
            // schimaOfDB();
        }

        //Initialize values
        private void Initialize()
        {
            server = "localhost";
            database = "connectcsharptomysql";
            uid = "username";
            password = "password";
            string MyConnection2 = "server=localhost;uid=root;database=shop;persistsecurityinfo=True;port=3306;SslMode=none";
            string MyDbSchema = "Provider=SQLOLEDB;Data Source=localhost;User ID=root;Password = ; Initial Catalog = Northwind";
            connection = new MySqlConnection(MyConnection2);
            oledb = new OleDbConnection(MyDbSchema);
        }

        //open connection to database
        private bool OpenConnection()
        {
            try
            {
                connection.Open();
                return true;
            }
            catch (MySqlException ex)
            {
                //When handling errors, you can your application's response based 
                //on the error number.
                //The two most common error numbers when connecting are as follows:
                //0: Cannot connect to server.
                //1045: Invalid user name and/or password.
                switch (ex.Number)
                {
                    case 0:
                        MessageBox.Show("Cannot connect to server.  Contact administrator");
                        break;

                    case 1045:
                        MessageBox.Show("Invalid username/password, please try again");
                        break;
                }
                return false;
            }
        }

        //Close connection
        private bool CloseConnection()
        {
            try
            {
                connection.Close();
                return true;
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
        }

        //Insert statement
        public bool Insert(string query)
        {
            // string query = "INSERT INTO tableinfo (name, age) VALUES('John Smith', '33')";
            bool flag = false;
            //open connection
            if (this.OpenConnection() == true)
            {
                //create command and assign the query and connection from the constructor
                MySqlCommand cmd = new MySqlCommand(query, connection);

                //Execute command
                cmd.ExecuteNonQuery();

                //close connection
                this.CloseConnection();
                flag = true;
            }
            return flag;
        }


        //Update statement
        public void Update()
        {
        }


        //Delete statement
        public void Delete()
        {
        }


        //Select statement
        public List<string>[] Select()
        {
            string query = "SELECT * FROM `gk`";

            List<string>[] list = new List<string>[5];
            list[0] = new List<string>();
            list[1] = new List<string>();
            list[2] = new List<string>();
            list[3] = new List<string>();
            list[4] = new List<string>();

            //Open connection
            if (this.OpenConnection() == true)
            {

                //Create Command
                MySqlCommand cmd = new MySqlCommand(query, connection);
                //Create a data reader and Execute the command
                MySqlDataReader dataReader = cmd.ExecuteReader();

                //Read the data and store them in the list
                while (dataReader.Read())
                {
                    list[0].Add(dataReader[1] + "");
                    list[1].Add(dataReader[2] + "");
                    list[2].Add(dataReader[3] + "");
                    list[3].Add(dataReader[4] + "");
                }

                //close Data Reader
                dataReader.Close();

                //close Connection
                this.CloseConnection();

                //return list to be displayed
                return list;
            }
            else
            {
                return list;
            }
        }

        //Count statement
        public int Count(string table)
        {

            string query = "SELECT Count(*) FROM "+table;
            int Count = -1;

            //Open Connection
            if (this.OpenConnection() == true)
            {
                //Create Mysql Command
                MySqlCommand cmd = new MySqlCommand(query, connection);

                //ExecuteScalar will return one value
                Count = int.Parse(cmd.ExecuteScalar() + "");

                //close Connection
                this.CloseConnection();

                return Count;
            }
            else
            {
                return Count;
            }
        }

        //Backup
        public void Backup()
        {
        }


        //Restore
        public void Restore()
        {
        }


        public void schimaOfDB()
        {
            oledb.Open();
            //Retrieve schema information about tables.
            //Because tables include tables, views, and other objects,
            //restrict to just TABLE in the Object array of restrictions.
            DataTable schemaTable = oledb.GetOleDbSchemaTable(OleDbSchemaGuid.Tables,
                           new Object[] { null, null, null, "TABLE" });

            //List the table name from each row in the schema table.
            for (int i = 0; i < schemaTable.Rows.Count; i++)
            {
                Console.WriteLine(schemaTable.Rows[i].ItemArray[2].ToString());
            }

            //Explicitly close - don't wait on garbage collection.
            oledb.Close();

            //Pause
            Console.ReadLine();
        }

        //Select data from Category_table
        public List<string>[] selectCategoryTable()
        {
            String query = "Select * from `category_table`";
            List<string>[] list = new List<string>[5];
            list[0] = new List<string>();
            list[1] = new List<string>();
            list[2] = new List<string>();
            list[3] = new List<string>();
            list[4] = new List<string>();

            //Open connection
            if (this.OpenConnection() == true)
            {
                //Create Command
                MySqlCommand cmd = new MySqlCommand(query, connection);
            //Create a data reader and Execute the command
            MySqlDataReader dataReader = cmd.ExecuteReader();

            //Read the data and store them in the list
            while (dataReader.Read())
            {
                list[0].Add(dataReader[0] + "");
                list[1].Add(dataReader[1] + "");
            }

            //close Data Reader
            dataReader.Close();

            //close Connection
            this.CloseConnection();

            //return list to be displayed
            return list;
        }
            else
            {
                return list;
            }
}

    }
}
