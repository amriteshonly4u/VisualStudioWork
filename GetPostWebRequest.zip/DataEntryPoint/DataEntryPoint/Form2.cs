﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TextQuestionToDB;

namespace DataEntryPoint
{
    public partial class Form2 : Form
    {
        DBConnection dbConnection;
        string selectValue;

        public Form2()
        {
            InitializeComponent();
            dbConnection = new DBConnection();
            textBox1.Text = Convert.ToString(dbConnection.Count("sub_category_table") + 1);
            clear();

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void clear()
        {
            textBox2.Text = "";
            textBox1.Text = Convert.ToString(dbConnection.Count("sub_category_table") + 1);

           List<string>[] list =  dbConnection.selectCategoryTable().ToArray<List<string>>();
            listBox1.Items.Add("Hello");
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            selectValue = listBox1.SelectedItem.ToString();
            Console.WriteLine(listBox1.SelectedItem);
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }
    }
}
