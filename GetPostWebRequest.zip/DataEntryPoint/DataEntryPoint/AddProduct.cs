﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DataEntryPoint
{
    public partial class AddProduct : Form
    {
        private static readonly HttpClient client = new HttpClient();
        public AddProduct()
        {
            InitializeComponent();
        }

        async private void AddProduct_Load(object sender, EventArgs e)
        {
            await fill_data();
        }
        async Task<int> fill_data()
        {
            await Task.Run(() => {
                sendReq();
            });
            return (1);
        }
        async void sendReq()
        {
            string s = "something went wrong";
            string url = "http://biharilegends.com/biharilegends.com/market_go/run_query_post.php";
            var values = new Dictionary<string, string>
            {
               { "query", "select * from security_table" }
            };
            var content = new FormUrlEncodedContent(values);
            using (HttpClient httpClient = new HttpClient()) // must use to avoid Android freezes after repeated calls
            {
                if (true)
                {
                    var response = await client.PostAsync(url, content);
                    s = await response.Content.ReadAsStringAsync();
                }
                else
                {
                    //Get request 
                    s = await httpClient.GetStringAsync(url);
                }
            }
            Debug.Print( s);
        }
    }
}
